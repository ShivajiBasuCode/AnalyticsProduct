﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealityCS.DTO.Global
{
    public class ManageSateDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}

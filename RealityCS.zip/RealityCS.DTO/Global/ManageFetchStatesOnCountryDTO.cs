﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealityCS.DTO.Global
{
    public class ManageFetchStatesOnCountryDTO
    {
        public int CountryID { get; set; }
    }
}

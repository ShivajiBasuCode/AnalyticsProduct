﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealityCS.DTO.GraphicalEntity
{
    public class ManageFetchAllRealyticsCardInformationForDashboardInVisualisationDTO
    {
        public int DashboardId { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealityCS.DTO.GraphicalEntity
{
    public class ManageFetchDashboardInformationInVisualisationDTO
    {
        public bool OrderByDashboard { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealityCS.DTO.Admin
{
    public class DTO_KPI_TLT
    {
        public int KPI_TLT_ID { get; set; }
        public string KPI_CD { get; set; }
        public string TLT_CD { get; set; }
        public bool ACTIVE { get; set; }
    }

}

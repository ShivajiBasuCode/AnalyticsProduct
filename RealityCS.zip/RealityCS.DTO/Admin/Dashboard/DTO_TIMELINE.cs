﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealityCS.DTO.Admin.Dashboard
{
    public class DTO_TIMELINE
    {
        public int TLT_ID { get; set; }
        public string TLT_CD { get; set; }
        public string ORG_CD { get; set; }
        public string TLT_TYPE { get; set; }
    }
}

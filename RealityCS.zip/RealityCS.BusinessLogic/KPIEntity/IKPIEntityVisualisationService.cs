﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealityCS.BusinessLogic.KPIEntity
{
    public interface IKPIEntityVisualisationService
    {
    }
}
